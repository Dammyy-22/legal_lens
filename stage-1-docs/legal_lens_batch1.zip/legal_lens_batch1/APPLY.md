# Applying Batch 1

Prerequisite: the Stage 1 docs commits from the earlier bundle (or apply this patch on top of `main` after applying that one).

    git checkout -b fix/batch-1-gates-and-zdr
    git am batch1.patch            # keeps my commit
    cd apps/web && npm ci && npm run lint && npx tsc --noEmit
    git push -u origin fix/batch-1-gates-and-zdr

`files/` holds the changed files in repo layout if you prefer to copy them over manually. Read `docs/engineering/CHANGELOG.md` ("Required before deploy") before merging to main.
