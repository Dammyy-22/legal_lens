# Applying the Stage 1 docs

Copy `docs/` into the root of `legal_lens`, then:

    git checkout -b audit/stage-1-docs
    git add docs && git commit -m "docs: Stage 1 audit and plan"
    git push -u origin audit/stage-1-docs

Or keep my two commits: from the repo root, `git checkout -b audit/stage-1-docs && git am stage1-docs.patch && git push -u origin audit/stage-1-docs`.
