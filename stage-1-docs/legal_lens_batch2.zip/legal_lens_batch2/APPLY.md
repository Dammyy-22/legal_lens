# Applying Batch 2

Needs Batch 1 applied first (this patch is on top of it).

    git checkout fix/batch-1-gates-and-zdr       # or merge Batch 1 first
    git checkout -b fix/batch-2-document-consent
    git am batch2.patch
    git push -u origin fix/batch-2-document-consent

Do NOT merge to main until the migration has been tested on staging: see `files/docs/operations/staging-setup.md` and the "Deploy order" in `files/docs/engineering/CHANGELOG.md`.
