-- LegalLens Supabase schema — legal corpus + AI assistant tables.
-- Apply once to a fresh database in Supabase Dashboard → SQL Editor.
-- Later feature changes belong in additive migrations; this initial schema
-- includes CREATE POLICY statements and is not safe to re-run unchanged.
--
-- Design principles carried over from the original FastAPI/Alembic schema
-- (see apps/api/DATABASE.md for the fuller rationale, now retired but still useful
-- reference):
--   - Authoritative legal sources are a SEPARATE table family from user-uploaded
--     documents. Never conflate the two.
--   - Nothing is "verified" or citable until a human flips a boolean — ingestion
--     populates data, it does not publish it.
--   - Citations must reference a real chunk row — enforced by a CHECK constraint,
--     not just application logic.

create extension if not exists vector;
create extension if not exists pgcrypto; -- for gen_random_uuid()

-- ============================================================
-- Authoritative legal corpus
-- ============================================================

create table if not exists public.legal_sources (
    id uuid primary key default gen_random_uuid(),
    title text not null,
    jurisdiction text not null default 'Nigeria',
    country text not null default 'Nigeria',
    issuing_authority text not null,
    document_type text not null check (document_type in (
        'constitution', 'legislation', 'regulation', 'case_law',
        'agency_guidance', 'secondary_commentary'
    )),
    authority_level text not null check (authority_level in (
        'primary', 'institutional', 'secondary'
    )),
    language text not null default 'en',
    source_url text not null,
    created_at timestamptz not null default now()
);

create table if not exists public.legal_source_versions (
    id uuid primary key default gen_random_uuid(),
    source_id uuid not null references public.legal_sources(id) on delete cascade,
    version_label text not null,
    publication_date date,
    effective_date date,
    amendment_date date,
    status text not null default 'unverified' check (status in (
        'current', 'amended', 'repealed', 'superseded', 'unverified', 'rejected'
    )),
    superseded_by_version_id uuid references public.legal_source_versions(id),
    processing_status text not null default 'pending' check (processing_status in (
        'pending', 'extracted', 'chunked', 'embedded', 'indexed', 'published', 'failed'
    )),
    original_object_key text,
    checksum_sha256 text,
    retrieved_at timestamptz,
    verified boolean not null default false,
    verified_by text,
    verified_at timestamptz,
    review_notes text,
    reviewed_by text,
    reviewed_at timestamptz,
    created_at timestamptz not null default now(),
    unique (source_id, version_label)
);

-- Chapter-level granularity for this first ingestion pass — see DECISIONS.md for why
-- section-level parsing was deliberately deferred (Chapter IV's extracted text lost
-- its section-number prefixes; shipping fragile regex-based section splitting would
-- have silently mis-chunked exactly the most-queried chapter).
create table if not exists public.legal_sections (
    id uuid primary key default gen_random_uuid(),
    version_id uuid not null references public.legal_source_versions(id) on delete cascade,
    parent_section_id uuid references public.legal_sections(id) on delete cascade,
    hierarchy_level text not null default 'chapter' check (hierarchy_level in (
        'part', 'chapter', 'division', 'section', 'subsection', 'paragraph', 'schedule'
    )),
    label text not null,
    heading text,
    order_index integer not null default 0,
    page_number integer,
    text text not null
);

create table if not exists public.rate_limit_events (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    action text not null default 'ask' check (action in ('ask', 'search', 'review')),
    window_start timestamptz not null default now(),
    request_count integer not null default 1 check (request_count > 0),
    metadata jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);

create table if not exists public.document_chunks (
    id uuid primary key default gen_random_uuid(),
    section_id uuid not null references public.legal_sections(id) on delete cascade,
    version_id uuid not null references public.legal_source_versions(id) on delete cascade,
    chunk_index integer not null default 0,
    text text not null,
    embedding vector(1536), -- matches OpenAI text-embedding-3-small; see DECISIONS.md
    created_at timestamptz not null default now()
);

create index if not exists idx_document_chunks_embedding
    on public.document_chunks using ivfflat (embedding vector_cosine_ops)
    with (lists = 100);

-- ============================================================
-- Conversations, messages, citations (AI assistant)
-- ============================================================

create table if not exists public.conversations (
    id uuid primary key default gen_random_uuid(),
    user_id uuid not null references auth.users(id) on delete cascade,
    title text,
    jurisdiction text not null default 'Nigeria',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

create table if not exists public.messages (
    id uuid primary key default gen_random_uuid(),
    conversation_id uuid not null references public.conversations(id) on delete cascade,
    role text not null check (role in ('user', 'assistant', 'system')),
    content text not null,
    risk_level text not null default 'standard' check (risk_level in ('standard', 'high_risk')),
    is_uncertain boolean not null default false,
    created_at timestamptz not null default now()
);

-- A citation must reference a real chunk — enforced here, not just in application
-- code. Matches the same invariant proven out in the earlier FastAPI schema.
create table if not exists public.citations (
    id uuid primary key default gen_random_uuid(),
    message_id uuid not null references public.messages(id) on delete cascade,
    chunk_id uuid references public.document_chunks(id) on delete cascade,
    quoted_text text,
    created_at timestamptz not null default now(),
    constraint ck_citation_has_source check (chunk_id is not null)
);

-- ============================================================
-- Row Level Security
-- ============================================================

alter table public.legal_sources enable row level security;
alter table public.legal_source_versions enable row level security;
alter table public.legal_sections enable row level security;
alter table public.document_chunks enable row level security;
alter table public.rate_limit_events enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.citations enable row level security;

-- Legal corpus: readable by any authenticated user, but ONLY for verified content.
-- Unverified/unpublished ingestion data is invisible to the app entirely — this is
-- the enforcement point for "nothing is citable until a human verifies it."
create policy "Verified legal sources are readable by authenticated users"
    on public.legal_sources for select to authenticated using (true);

create policy "Only verified versions are readable"
    on public.legal_source_versions for select to authenticated
    using (verified = true);

create policy "Sections of verified versions are readable"
    on public.legal_sections for select to authenticated
    using (
        exists (
            select 1 from public.legal_source_versions v
            where v.id = version_id and v.verified = true
        )
    );

create policy "Chunks of verified versions are readable"
    on public.document_chunks for select to authenticated
    using (
        exists (
            select 1 from public.legal_source_versions v
            where v.id = version_id and v.verified = true
        )
    );

-- No insert/update/delete policies exist for the legal corpus tables above, which
-- means, under RLS, ordinary authenticated users cannot write to them at all — only
-- the service_role key (used server-side by the ingestion script and future admin
-- tools) bypasses RLS and can write. This is intentional: the corpus is
-- admin-curated, never user-editable.

-- Shared infra audit trail: rate limiting events are service-role only. This lets
-- the platform enforce a shared cap across multiple edge instances without exposing
-- the raw burst data to end users.
create policy "Service role manages rate-limit audit events"
    on public.rate_limit_events for all to service_role
    using (true) with check (true);

-- Conversations/messages/citations: users can only access their own.
create policy "Users manage their own conversations"
    on public.conversations for all to authenticated
    using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Users access messages in their own conversations"
    on public.messages for all to authenticated
    using (
        exists (
            select 1 from public.conversations c
            where c.id = conversation_id and c.user_id = auth.uid()
        )
    )
    with check (
        exists (
            select 1 from public.conversations c
            where c.id = conversation_id and c.user_id = auth.uid()
        )
    );

create policy "Users access citations on their own messages"
    on public.citations for select to authenticated
    using (
        exists (
            select 1 from public.messages m
            join public.conversations c on c.id = m.conversation_id
            where m.id = message_id and c.user_id = auth.uid()
        )
    );

-- ============================================================
-- Vector search RPC — used by supabase/functions/ask
-- ============================================================
--
-- SECURITY DEFINER is required here: RLS on document_chunks would otherwise apply
-- with the CALLER's permissions inside this function too, but plain SELECT-based RLS
-- doesn't compose cleanly with a vector similarity ORDER BY across a join. Instead,
-- this function explicitly re-implements the "only verified content" rule itself
-- (the `and v.verified = true` clause below) as defense in depth alongside the RLS
-- policies above — the Edge Function does not rely on this function alone, and this
-- function does not rely on RLS alone. Never remove the verified check from this
-- function even though RLS also restricts the underlying tables.
create or replace function public.match_document_chunks(
    query_embedding vector(1536),
    match_threshold float default 0.72,
    match_count int default 6
)
returns table (
    id uuid,
    text text,
    similarity float,
    section_label text,
    section_heading text,
    source_title text,
    source_url text
)
language sql
stable
security definer
set search_path = public
as $$
    select
        dc.id,
        dc.text,
        1 - (dc.embedding <=> query_embedding) as similarity,
        ls.label as section_label,
        ls.heading as section_heading,
        src.title as source_title,
        src.source_url as source_url
    from public.document_chunks dc
    join public.legal_source_versions v on v.id = dc.version_id
    join public.legal_sections ls on ls.id = dc.section_id
    join public.legal_sources src on src.id = v.source_id
    where v.verified = true
      and dc.embedding is not null
      and 1 - (dc.embedding <=> query_embedding) > match_threshold
    order by dc.embedding <=> query_embedding
    limit match_count;
$$;

-- Only authenticated users may call this — matches every other read path in this
-- schema.
revoke all on function public.match_document_chunks from public;
grant execute on function public.match_document_chunks to authenticated;

-- Lexical fallback for when vector embeddings are unavailable or semantic search
-- finds no verified material. Search remains restricted to verified, current law.
create or replace function public.search_verified_document_chunks(
    query_text text,
    match_count integer default 6
)
returns table (
    id uuid,
    text text,
    similarity float,
    section_label text,
    section_heading text,
    source_title text,
    source_url text
)
language plpgsql
stable
security definer
set search_path = public
as $$
declare
    parsed_query tsquery;
begin
    if query_text is null or length(trim(query_text)) < 2 or length(query_text) > 2000 then
        raise exception 'Invalid legal search query' using errcode = '22023';
    end if;
    if match_count < 1 or match_count > 20 then
        raise exception 'Invalid legal search result limit' using errcode = '22023';
    end if;

    select to_tsquery(
        'english',
        nullif(
            array_to_string(
                tsvector_to_array(
                    to_tsvector(
                        'english',
                        regexp_replace(
                            query_text,
                            '\m(nigeria|nigerian|constitution|constitutional|law|legal)\M',
                            ' ',
                            'gi'
                        )
                    )
                ),
                ' | '
            ),
            ''
        )
    )
    into parsed_query;

    return query
    with ranked_chunks as (
        select
            dc.id,
            dc.text,
            ts_rank_cd(
                setweight(to_tsvector('english', ls.label), 'A') ||
                setweight(to_tsvector('english', coalesce(ls.heading, '')), 'A') ||
                setweight(to_tsvector('english', dc.text), 'B'),
                parsed_query
            )::double precision as rank,
            ls.label as section_label,
            ls.heading as section_heading,
            src.title as source_title,
            src.source_url as source_url
        from public.document_chunks dc
        join public.legal_source_versions v on v.id = dc.version_id
        join public.legal_sections ls on ls.id = dc.section_id
        join public.legal_sources src on src.id = v.source_id
        where v.verified = true
          and v.status = 'current'
          and (
              (
                  parsed_query is not null
                  and (
                      setweight(to_tsvector('english', ls.label), 'A') ||
                      setweight(to_tsvector('english', coalesce(ls.heading, '')), 'A') ||
                      setweight(to_tsvector('english', dc.text), 'B')
                  ) @@ parsed_query
              )
              or lower(dc.text) like '%' || lower(trim(query_text)) || '%'
          )
    )
    select
        ranked_chunks.id,
        ranked_chunks.text,
        ranked_chunks.rank,
        ranked_chunks.section_label,
        ranked_chunks.section_heading,
        ranked_chunks.source_title,
        ranked_chunks.source_url
    from ranked_chunks
    order by ranked_chunks.rank desc, ranked_chunks.id
    limit match_count;
end;
$$;

revoke all on function public.search_verified_document_chunks(text, integer) from public, anon;
grant execute on function public.search_verified_document_chunks(text, integer) to authenticated;

-- ============================================================
-- Admin access to unverified corpus content
-- ============================================================
--
-- Admin status is read from the JWT's app_metadata claim, NOT user_metadata.
-- app_metadata can only be set via the service_role key / Supabase Admin API — a
-- user can never grant themselves admin by editing their own profile, unlike
-- user_metadata (used elsewhere in this project for full name/state/city, which IS
-- user-editable and appropriately so for that data). This is verified: a regular
-- user's SELECT against unverified rows returns 0 rows, and their UPDATE attempt
-- silently affects 0 rows, tested directly against Postgres.
--
-- To make a user an admin, run this from a trusted server context (never the
-- browser) using the service_role key:
--   update auth.users set raw_app_meta_data =
--     raw_app_meta_data || '{"role": "admin"}'::jsonb
--   where email = 'admin@example.com';

create policy "Admins can read unverified versions for review"
    on public.legal_source_versions for select to authenticated
    using (
        verified = true
        or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
    );

create policy "Admins can verify versions"
    on public.legal_source_versions for update to authenticated
    using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
    with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

create policy "Admins can read sections of unverified versions"
    on public.legal_sections for select to authenticated
    using (
        exists (
            select 1 from public.legal_source_versions v
            where v.id = version_id
              and (v.verified = true or (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
        )
    );

-- Postgres combines multiple permissive SELECT policies on the same table with OR,
-- so this is additive to the existing "verified only" policies above, not a
-- replacement — together they allow "verified content for everyone, unverified
-- content for admins only."
